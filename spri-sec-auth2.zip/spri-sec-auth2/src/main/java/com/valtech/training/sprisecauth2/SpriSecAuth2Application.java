package com.valtech.training.sprisecauth2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpriSecAuth2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpriSecAuth2Application.class, args);
	}

}
